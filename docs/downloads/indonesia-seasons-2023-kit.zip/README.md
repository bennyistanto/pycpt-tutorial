# Indonesia seasonal tutorial kit

Extract this entire archive. Open docs/notebooks/indonesia-seasons-2023.ipynb
from this directory or a subdirectory. The notebook discovers this kit's root.
Its default saved-results execution needs scientific Python packages, not a
PyCPT installation, CPT executable or IRI Data Library credentials.

For offline analysis, create a NEW scientific-Python environment:

    conda env create -f environment/offline-analysis.yml
    conda activate pycpt-tutorial-analysis
    python -m ipykernel install --user --name pycpt-tutorial-analysis --display-name 'Python (Tutorial Analysis)'
    jupyter notebook docs/notebooks/indonesia-seasons-2023.ipynb

Choose Python (Tutorial Analysis), then run all cells. Creating the environment
requires package downloads; subsequent default notebook execution is offline.
The optional OND calibration through PyCPT requires the separate tested fitting
environment (PyCPT 2.10.4, cptio 1.4.0, CPT 17.8.3):

    conda create -n pycpt-tutorial --file environment/conda-linux-64.lock
    conda activate pycpt-tutorial

This explicit lock is for the tested Linux x86-64 runtime. The offline-analysis
YAML lists direct package versions matching that runtime and contains no PyCPT
or CPT dependency; it is not a complete cross-platform lock.
It writes a unique scratch directory under temp/ and preserves saved inputs.

Calendar: all target midpoints in 2023. NDJ ends in January 2024 and preserves the
research ending-year 2024 label. This is a retrospective deterministic case study,
not evidence of general or probabilistic forecast skill.

Data attribution: CHIRPS3, Climate Hazards Center, UC Santa Barbara,
https://doi.org/10.15780/G2JQ0P and https://www.chc.ucsb.edu/data/chirps3 .
Model source: NCEP CFSv2 through the IRI Data Library; exact source hashes and
calendar selections are in docs/data/provenance.json. Teaching fields are seasonal
totals at the native 0.05 degree grid, at every pixel that touches Indonesia.

Boundary overlays: supplied Indonesia country/province and world shapefiles,
cropped and simplified for display. Indonesia metadata credits Badan Informasi
Geospasial, modified by Benny Istanto. See docs/data/boundaries/README.md and
provenance.json for source hashes and processing; overlays do not affect analysis.
The analysis keeps every pixel that touches the unsimplified supplied province file;
each pixel belongs to the province covering most of it. See docs/data/regions/README.md.
The notebook exports province means of pixel errors, not a new provincial rainfall product.
