# Fit and diagnose rainfall forecasts: OND/JJA 2023

Extract this entire kit. The executed notebook is
docs/notebooks/fit-diagnose-2023.ipynb. Reading saved outputs requires only a
notebook viewer. Executing all cells makes four actual PyCPT fits and requires
the FULL tested Linux x86-64 PyCPT environment and its compatible CPT engine.
The analysis-only environment does not execute these fitting cells.

From this extracted directory with conda available:

    conda create -n pycpt-tutorial --file environment/conda-linux-64.lock
    conda activate pycpt-tutorial
    python -m ipykernel install --user --name pycpt-tutorial --display-name "Python (PyCPT Tutorial)"
    jupyter notebook docs/notebooks/fit-diagnose-2023.ipynb

If the fitting environment already exists, activate it instead of creating it
again. Choose Python (PyCPT Tutorial); run top to bottom. Every execution creates
a unique temp/ directory and writes new derived NetCDF/CSV/PNG outputs under
docs/assets/fitting-2023/. The notebook creates any missing output folders.
Initial conda installation can require package downloads. Notebook execution
uses the supplied local inputs and does not need an IRIDL key or new downloads.
Credentials and source preparation drives are not included or required.

The conda release is PyCPT 2.10.4; Python package metadata may report 2.10.4.dev0.
The notebook records both and verifies the audited engine/wrapper hashes. Native
fit logs and commands are retained with outputs. Do not build a standalone engine
or substitute an unverified runtime for this controlled replay.

Training 1991-2020; targets OND/JJA 2023; CCA with 3 X EOFs, 3 Y EOFs and 2 CCA modes,
and PCR with 3 X EOFs; cyclic cross-validation window of 5.
Patterns describe full-training relationships, not per-fold or independent skill.
Native weights and explicit field-score correlations are exported separately.
No model tuning, physical attribution or empirical probability reliability claim.
Native probability/variance fields are retained as outputs, not scored here.

Inputs/controls: docs/data/fitting-2023/provenance.json. Model source is NCEP CFSv2
through the IRI Data Library; observations are CHIRPS3, Climate Hazards Center/
UCSB (https://doi.org/10.15780/G2JQ0P). Supplied Indonesia boundaries credit BIG,
modified by Benny Istanto. Display boundaries do not change scoring support.
See docs/data/boundaries/README.md and provenance.json for attribution/hashes.
Code license: Mozilla Public License 2.0, see LICENSE; data retain source terms.
