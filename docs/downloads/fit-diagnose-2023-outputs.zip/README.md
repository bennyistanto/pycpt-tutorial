# OND/JJA 2023 fitted outputs

Thirty NetCDFs from four isolated local-input PyCPT fits. The execution manifest
records runtime, configuration, control comparisons and each file hash.
Forecast-comparison and deterministic-scores summarize the selected 2023 examples;
CV-yearly-scores and CV-residual-summary describe deterministic training cross-validation.
Per-fit files retain all returned datasets. Clean predictor/predictand diagnostics
use separate EOF/CCA/spectrum axes, explicitly decoded masks and separately named
native weights and field-score correlations. They describe full-training models.
Native probabilities/variance are preserved, not evidence of empirical reliability.
See the executed fitting notebook and tutorial story for interpretation.
Observations: CHIRPS3, Climate Hazards Center/UCSB, https://doi.org/10.15780/G2JQ0P.
Model: NCEP CFSv2 via IRI Data Library. Source data retain their original terms.
